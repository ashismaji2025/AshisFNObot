# AshisF-Obot

A private Telegram trading advisor bot for Nifty and Bank Nifty Futures & Options.
